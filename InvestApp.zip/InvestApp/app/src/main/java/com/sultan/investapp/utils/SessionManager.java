package com.sultan.investapp.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

public class SessionManager {
    private SharedPreferences prefs;
    private Context context;

    public SessionManager(Context context) {
        this.context = context;
    }

    public Long getUserId() {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        return prefs.getLong(Constants.USER_ID, 0L);
    }

    public void saveUserId(Long id) {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(Constants.USER_ID, id);
        editor.apply();
    }

    public void saveUserUid(String uid) {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(Constants.USER_UID, uid);
        editor.apply();
    }

    public String getUserUid() {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        return prefs.getString(Constants.USER_UID, " ");
    }

    public boolean isAuthenticated() {
        return (!getUserUid().equals(" ") && !getUserUid().isEmpty() && getUserUid().length() > 1);
    }

    public void saveUserKey(String key) {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(Constants.USER_KEY, key);
        editor.apply();
    }

    public String getUserKey() {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        return prefs.getString(Constants.USER_KEY, "");
    }

    public String getUserEmail() {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        return prefs.getString(Constants.USER_EMAIL, "");
    }

    public void saveUserEmail(String email) {
        prefs = context.getSharedPreferences(Constants.MY_SETTINGS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(Constants.USER_EMAIL, email);
        editor.apply();
    }


}
