package com.sultan.investapp.utils;

import android.util.TypedValue;

public class Constants {
    public static final String MY_SETTINGS = "SETTINGS";
    public static final String USER_ID = "USER_ID";
    public static final String USER_UID = "USER_UID";
    public static final String USER_KEY = "USER_KEY";
    public static final String TOKEN = "USER_TOKEN";
    public static final String USER_EMAIL = "USER_EMAIL";
    public static final String EXTRA_CURRENT_USER_ID = "EXTRA_CURRENT_USER_ID";
    public static final String EXTRA_RECIPIENT_ID = "EXTRA_RECIPIENT_ID";
    public static final String EXTRA_CHAT_REF = "EXTRA_CHAT_REF";
}
