package com.sultan.investapp.ui.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.sultan.investapp.R;
import com.sultan.investapp.ui.login.LoginFragment;
import com.sultan.investapp.utils.SessionManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    SessionManager sm;
    public static BottomNavigationView navView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(Color.WHITE);

        sm = new SessionManager(this);
        navView = findViewById(R.id.nav_view);
        NavController navController = Navigation.findNavController(this, R.id.my_nav_host_fragment);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.startup_nav:
                    navController.navigate(R.id.navigation_startups);
                    break;
                case R.id.messenger_nav:
                    if (sm.isAuthenticated())
                        navController.navigate(R.id.navigation_messenger);
                    else
                        Snackbar.make(navView, "Login first", Snackbar.LENGTH_SHORT).show();
                    break;
                case R.id.cabinet_nav:
                    if (sm.isAuthenticated()) {
                        navController.navigate(R.id.navigation_cabinet);
                    } else {
                        startActivity(new Intent(MainActivity.this, AuthActivity.class));
                    }
                    break;
            }
            return true;
        });
    }

    public static void updateNavigationBarState(int itemId) {
        MenuItem item = navView.getMenu().findItem(itemId);
        item.setChecked(true);
    }
}
