package com.sultan.investapp.ui.messenger;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sultan.investapp.R;
import com.sultan.investapp.model.ChatMessage;
import com.sultan.investapp.ui.adapter.MessageChatAdapter;
import com.sultan.investapp.utils.Constants;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {

    private String mRecipientId;
    private String mCurrentUserId;
    DatabaseReference messageChatDatabase;
    RecyclerView mChatRecyclerView;
    EditText mUserMessageChatText;
    MessageChatAdapter messageChatAdapter;
    ChildEventListener messageChatListener;
    Button send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        setDatabaseInstance();
        setUsersId();
        send = findViewById(R.id.btn_send_message);
        mChatRecyclerView = findViewById(R.id.recycler_view_chat);
        mUserMessageChatText = findViewById(R.id.edit_text_message);
        mChatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mChatRecyclerView.setHasFixedSize(true);
        messageChatAdapter = new MessageChatAdapter(new ArrayList<ChatMessage>());
        mChatRecyclerView.setAdapter(messageChatAdapter);

        send.setOnClickListener(v -> {
            String senderMessage = mUserMessageChatText.getText().toString().trim();
            if (!senderMessage.isEmpty()) {
                ChatMessage newMessage = new ChatMessage(senderMessage, mCurrentUserId, mRecipientId);
                messageChatDatabase.push().setValue(newMessage);
                mUserMessageChatText.setText("");
            }
        });
    }

    private void setDatabaseInstance() {
        String chatRef = getIntent().getStringExtra(Constants.EXTRA_CHAT_REF);
        messageChatDatabase = FirebaseDatabase.getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app")
                .getReference()
                .child(chatRef);
    }

    private void setUsersId() {
        mRecipientId = getIntent().getStringExtra(Constants.EXTRA_RECIPIENT_ID);
        mCurrentUserId = getIntent().getStringExtra(Constants.EXTRA_CURRENT_USER_ID);
    }

    @Override
    protected void onStart() {
        super.onStart();
        messageChatListener = messageChatDatabase.limitToFirst(20).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String previousChildKey) {

                if (dataSnapshot.exists()) {
                    ChatMessage newMessage = dataSnapshot.getValue(ChatMessage.class);
                    if (newMessage.getSender().equals(mCurrentUserId)) {
                        newMessage.setRecipientOrSenderStatus(MessageChatAdapter.SENDER);
                    } else {
                        newMessage.setRecipientOrSenderStatus(MessageChatAdapter.RECIPIENT);
                    }
                    messageChatAdapter.refillAdapter(newMessage);
                    mChatRecyclerView.scrollToPosition(messageChatAdapter.getItemCount() - 1);
                }

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}