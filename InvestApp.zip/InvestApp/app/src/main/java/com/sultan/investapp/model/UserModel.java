package com.sultan.investapp.model;

public class UserModel {
    public String email;
    public String fullname;
    public String uid;
    public String firebaseToken;

    public UserModel() {

    }

    public UserModel(String fullname, String email, String uid) {
        this.fullname = fullname;
        this.email = email;
        this.uid = uid;
    }

    public UserModel(String email, String fullname, String uid, String firebaseToken) {
        this.email = email;
        this.fullname = fullname;
        this.uid = uid;
        this.firebaseToken = firebaseToken;
    }

    public String getFullname() {
        return fullname;
    }

    public String getEmail() {
        return email;
    }

    public String getUid() {
        return uid;
    }

    public String getFirebaseToken() {
        return firebaseToken;
    }
}
