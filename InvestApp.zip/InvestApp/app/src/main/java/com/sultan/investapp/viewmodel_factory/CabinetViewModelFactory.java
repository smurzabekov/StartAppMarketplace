package com.sultan.investapp.viewmodel_factory;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.sultan.investapp.repository.CabinetRepository;
import com.sultan.investapp.viewmodel.CabinetViewModel;

public class CabinetViewModelFactory implements ViewModelProvider.Factory {
    private final CabinetRepository cabinetRepository;

    public CabinetViewModelFactory(final CabinetRepository repository) {
        this.cabinetRepository = repository;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(CabinetViewModel.class)) {
            return (T) new CabinetViewModel(cabinetRepository);
        }
        throw new IllegalArgumentException("Unknown ViewModel class");
    }
}
