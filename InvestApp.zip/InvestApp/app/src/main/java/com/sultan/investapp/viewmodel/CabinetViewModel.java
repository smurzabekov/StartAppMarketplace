package com.sultan.investapp.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.sultan.investapp.model.UserModel;
import com.sultan.investapp.repository.CabinetRepository;

public class CabinetViewModel extends ViewModel {

    private CabinetRepository cabinetRepository;

    public CabinetViewModel(final CabinetRepository repository) {
        this.cabinetRepository = repository;
    }

    public LiveData<UserModel> getUserByUid(String uid) {
        return cabinetRepository.getUserByUidRepository(uid);
    }
}
