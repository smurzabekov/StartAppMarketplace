package com.sultan.investapp.ui.cabinet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sultan.investapp.R;
import com.sultan.investapp.model.StartupModel;
import com.sultan.investapp.model.UserModel;
import com.sultan.investapp.repository.CabinetRepository;
import com.sultan.investapp.ui.activity.MainActivity;
import com.sultan.investapp.utils.SessionManager;
import com.sultan.investapp.viewmodel.CabinetViewModel;
import com.sultan.investapp.viewmodel_factory.CabinetViewModelFactory;

import java.util.Calendar;

public class CabinetFragment extends Fragment {

    private CabinetViewModel cabinetViewModel;
    TextView username, email;
    Button addStartup;
    SessionManager sm;
    String uid;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cabinet, container, false);

        username = v.findViewById(R.id.textview_username);
        email = v.findViewById(R.id.textview_email);
        addStartup = v.findViewById(R.id.btn_add_startup);

        sm = new SessionManager(requireContext());

        CabinetRepository cabinetRepository = new CabinetRepository(requireContext());
        final CabinetViewModelFactory cabinetViewModelFactory = new CabinetViewModelFactory(cabinetRepository);
        cabinetViewModel = new ViewModelProvider(getViewModelStore(), cabinetViewModelFactory).get(CabinetViewModel.class);
        cabinetViewModel.getUserByUid(sm.getUserUid()).observe(getViewLifecycleOwner(), data -> {
            updateUI(data);
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        MainActivity.updateNavigationBarState(R.id.cabinet_nav);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        addStartup.setOnClickListener(v ->  {

            final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireContext());
            bottomSheetDialog.setContentView(R.layout.bottom_sheet_add_startup);

            EditText description = bottomSheetDialog.findViewById(R.id.textview_description);
            EditText imageUrl = bottomSheetDialog.findViewById(R.id.textview_imageurl);
            Button add = bottomSheetDialog.findViewById(R.id.add);

            add.setOnClickListener(btn -> {
                add.startAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.bubble));

                String d = description.getText().toString().trim();
                String i = imageUrl.getText().toString().trim();
                if (d.isEmpty()) {
                    description.setError("Add description");
                }
                else if (i.isEmpty()) {
                    imageUrl.setError("Startup must contains image (url)");
                }
                else {
                    FirebaseDatabase firebaseDatabase = FirebaseDatabase
                            .getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app");
                    DatabaseReference databaseReference = firebaseDatabase
                            .getReference()
                            .child("startups");

                    System.out.println(sm.getUserUid() + " sm");
                    databaseReference.push().setValue(new StartupModel(username.getText().toString(), sm.getUserEmail(), d,
                            Calendar.getInstance().getTime().toString(), 0L, 0L, 0L, i, sm.getUserUid()));

                    Snackbar.make(v, "Startup added", Snackbar.LENGTH_SHORT).show();

                    bottomSheetDialog.cancel();
                }
            });

            bottomSheetDialog.show();
        });
    }

    public void updateUI(UserModel user) {
        username.setText(user.getFullname());
        email.setText(user.getEmail());
    }
}
