package com.sultan.investapp.viewmodel;

import android.text.TextUtils;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sultan.investapp.model.StartupModel;
import com.sultan.investapp.model.UserModel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MessengerViewModel extends ViewModel {
    MutableLiveData<List<UserModel>> userList = new MutableLiveData<>();

    public MessengerViewModel() {

    }

    public MutableLiveData<List<UserModel>> getUserList() {
        return userList;
    }

    public void getUsers() {
        FirebaseDatabase.getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app")
                .getReference()
                .child("users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Iterator<DataSnapshot> dataSnapshots = dataSnapshot.getChildren()
                                .iterator();
                        List<UserModel> users = new ArrayList<>();
                        while (dataSnapshots.hasNext()) {
                            DataSnapshot dataSnapshotChild = dataSnapshots.next();

                            String fullname = dataSnapshotChild.child("fullname").getValue().toString();
                            String email = dataSnapshotChild.child("email").getValue().toString();
                            String uid1 = dataSnapshotChild.child("uid").getValue().toString();
                            System.out.println(fullname + " name");

                            UserModel user = new UserModel(fullname, email, uid1);
                            if (!TextUtils.equals(uid1,
                                    FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                                users.add(user);
                            }
                        }
                        userList.setValue(users);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("ERROR");
                    }
                });
    }

}
