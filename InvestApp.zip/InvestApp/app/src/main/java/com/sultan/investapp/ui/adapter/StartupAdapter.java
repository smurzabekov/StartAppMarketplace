package com.sultan.investapp.ui.adapter;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.sultan.investapp.R;
import com.sultan.investapp.model.StartupModel;

import java.util.List;

public class StartupAdapter extends RecyclerView.Adapter<StartupAdapter.ViewHolder> {

    List<StartupModel> startupModelList;
    private Context context;
    boolean expandable = true;
    boolean expand = false;

    public StartupAdapter(Context c) {
        this.context = c;
    }

    public void setStartupModelList(List<StartupModel> startupModelList) {
        this.startupModelList = startupModelList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StartupAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.startup_layout_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StartupAdapter.ViewHolder holder, int position) {
        StartupModel item = startupModelList.get(position);

        holder.name.setText(item.getUsername());
        holder.description.setText(item.getDescription());
        holder.date.setText(item.getPublishedAt());
        holder.likes.setText(context.getString(R.string.likes, item.getLikesCount()));
        holder.comments.setText(context.getString(R.string.comments, item.getCommentsCount()));
        holder.investors.setText(context.getString(R.string.investors, item.getInvestorsCount()));

        Glide.with(context)
                .load(item.getImageUrl())
                .fitCenter()
                .into(holder.startupImage);

        holder.more.setOnClickListener(v -> {
            if (holder.more.getText().toString().equalsIgnoreCase("More")) {
                holder.description.setMaxLines(Integer.MAX_VALUE);
                holder.more.setText("Less");
            } else {
                holder.description.setMaxLines(4);
                holder.more.setText("More");
            }
        });

        holder.invest.setOnClickListener(v -> {
            Dialog dialog = new Dialog(context, android.R.style.Theme_Dialog);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog);
            dialog.setCanceledOnTouchOutside(true);
            TextView email = dialog.findViewById(R.id.user_email);
            email.setText(item.getEmail());

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.show();
        });
    }

    @Override
    public int getItemCount() {
        return startupModelList != null ? startupModelList.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, date, likes, comments, investors, invest;
        ImageView userImage, startupImage;
        Button more;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textview_username);
            description = itemView.findViewById(R.id.textview_description);
            date = itemView.findViewById(R.id.textview_date);
            likes = itemView.findViewById(R.id.textview_like);
            comments = itemView.findViewById(R.id.textview_comments);
            investors = itemView.findViewById(R.id.textview_investors);
            startupImage = itemView.findViewById(R.id.imageview_startup);
            userImage = itemView.findViewById(R.id.imageview_user);
            more = itemView.findViewById(R.id.button_see_more);
            invest = itemView.findViewById(R.id.button_invest);
        }
    }
}
