package com.sultan.investapp.repository;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sultan.investapp.model.UserModel;

public class CabinetRepository {
    private final Context context;
    MutableLiveData<UserModel> userModelLiveData = new MutableLiveData<>();

    public CabinetRepository(final Context context) {
        this.context = context;
    }

    public LiveData<UserModel> getUserByUidRepository(String uid) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference mDatabase = FirebaseDatabase
                .getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app")
                .getReference();

        mDatabase.child("users").get().addOnCompleteListener((OnCompleteListener<DataSnapshot>) task -> {
            if (!task.isSuccessful()) {
                Log.e("firebase", "Error getting data", task.getException());
            }
            else {
                mDatabase.child("users").orderByChild("uid").equalTo(user.getUid())
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot datas: snapshot.getChildren()) {
                                    String fullname = datas.child("fullname").getValue().toString();
                                    String email = datas.child("email").getValue().toString();
                                    String uid1 = datas.child("uid").getValue().toString();
                                    userModelLiveData.setValue(new UserModel(fullname, email, uid1));
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
            }
        });
        return userModelLiveData;
    }
}
