package com.sultan.investapp.viewmodel;

public class LoginViewModel {

}
