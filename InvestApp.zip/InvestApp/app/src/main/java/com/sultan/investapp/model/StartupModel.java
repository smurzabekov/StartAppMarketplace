package com.sultan.investapp.model;

public class StartupModel {
    private String username;
    private String email;
    private String description;
    private String publishedAt;
    private Long likesCount;
    private Long commentsCount;
    private Long investorsCount;
    private String imageUrl;
    private String uid;

    public StartupModel(String username, String email, String description,
                        String publishedAt, Long likesCount, Long commentsCount, Long investorsCount, String imageUrl, String uid) {
        this.username = username;
        this.email = email;
        this.description = description;
        this.publishedAt = publishedAt;
        this.likesCount = likesCount;
        this.commentsCount = commentsCount;
        this.investorsCount = investorsCount;
        this.imageUrl = imageUrl;
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getDescription() {
        return description;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public Long getLikesCount() {
        return likesCount;
    }

    public Long getCommentsCount() {
        return commentsCount;
    }

    public Long getInvestorsCount() {
        return investorsCount;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
