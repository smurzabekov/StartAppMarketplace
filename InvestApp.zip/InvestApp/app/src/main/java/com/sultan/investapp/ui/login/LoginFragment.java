package com.sultan.investapp.ui.login;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.sultan.investapp.R;
import com.sultan.investapp.ui.activity.MainActivity;
import com.sultan.investapp.utils.SessionManager;

public class LoginFragment extends Fragment {

    EditText email, password;
    Button login, registration;
    FirebaseAuth mAuth;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_login, container, false);
        mAuth = FirebaseAuth.getInstance();

        email = v.findViewById(R.id.email);
        password = v.findViewById(R.id.password);
        login = v.findViewById(R.id.login);
        registration = v.findViewById(R.id.sign_up);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        registration.setOnClickListener(v -> {
            registration.startAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.bubble));
            NavHostFragment.findNavController(this).navigate(R.id.registrationFragment);
        });

        login.setOnClickListener(v -> {
            login.startAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.bubble));
            String userEmail = email.getText().toString().trim();
            String userPassword = password.getText().toString().trim();
            if (userEmail.isEmpty() || userEmail.length() < 1) {
                email.setError("Input correct E-Mail");
            } else if (userPassword.isEmpty() || userPassword.length() < 1) {
                password.setError("Input your password");
            } else {
                mAuth.signInWithEmailAndPassword(userEmail, userPassword)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Snackbar.make(v, "Successfully logged", Snackbar.LENGTH_SHORT).show();
                                SessionManager sm = new SessionManager(requireContext());
                                sm.saveUserUid(task.getResult().getUser().getUid());
                                System.out.println(task.getResult().getUser().getUid() + " uid");
                                sm.saveUserEmail(userEmail);
                                requireActivity().finish();
                            }
                        });
            }
        });
    }
}
