package com.sultan.investapp.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.sultan.investapp.R;
import com.sultan.investapp.ui.activity.MainActivity;
import com.sultan.investapp.ui.adapter.StartupAdapter;
import com.sultan.investapp.viewmodel.HomeViewModel;
import com.sultan.investapp.viewmodel.StartupsViewModel;

public class HomeFragment extends Fragment {

    private StartupsViewModel startupsViewModel;
    RecyclerView recyclerViewStartups;
    StartupAdapter startupAdapter;
    SwipeRefreshLayout refreshLayout;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        startupAdapter = new StartupAdapter(requireContext());
        recyclerViewStartups = v.findViewById(R.id.recyclerview_startups);
        recyclerViewStartups.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerViewStartups.setAdapter(startupAdapter);

        startupsViewModel = new ViewModelProvider(this).get(StartupsViewModel.class);

        startupsViewModel.getStartups();
        startupsViewModel.getList().observe(getViewLifecycleOwner(), list -> {
            startupAdapter.setStartupModelList(list);
        });

        refreshLayout = v.findViewById(R.id.refresh);
        refreshLayout.setOnRefreshListener(() -> {
            startupsViewModel.getStartups();
            refreshLayout.setRefreshing(false);
        });

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        MainActivity.updateNavigationBarState(R.id.startup_nav);
    }
}
