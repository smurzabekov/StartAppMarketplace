package com.sultan.investapp.viewmodel;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sultan.investapp.model.StartupModel;

import java.util.ArrayList;
import java.util.List;

public class StartupsViewModel extends ViewModel {
    MutableLiveData<List<StartupModel>> startups = new MutableLiveData<>();
    public StartupsViewModel() {

    }

    public LiveData<List<StartupModel>> getList() {
        return startups;
    }

    public void getStartups() {
       List<StartupModel> list = new ArrayList<>();
        //FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference mDatabase = FirebaseDatabase
                .getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app")
                .getReference();

        mDatabase.child("startups").get().addOnCompleteListener((OnCompleteListener<DataSnapshot>) task -> {
            if (!task.isSuccessful()) {
                Log.e("firebase", "Error getting data", task.getException());
            }
            else {
                mDatabase.child("startups")
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot datas: snapshot.getChildren()) {
                                    String fullname = datas.child("username").getValue().toString();
                                    String email = datas.child("email").getValue().toString();
                                    String published = datas.child("publishedAt").getValue().toString();
                                    String description = datas.child("description").getValue().toString();
                                    Long likesCount = Long.valueOf(datas.child("likesCount").getValue().toString());
                                    Long commentsCount = Long.valueOf(datas.child("commentsCount").getValue().toString());
                                    Long investorsCount = Long.valueOf(datas.child("investorsCount").getValue().toString());
                                    String imageUrl = datas.child("imageUrl").getValue().toString();
                                    //String uid1 = datas.child("uid").getValue().toString();

                                    list.add(new StartupModel(fullname, email, description, published,
                                            likesCount, commentsCount, investorsCount, imageUrl, "uid1"));
                                }
                                startups.setValue(list);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                System.out.println(error.getMessage() + " error");
                            }
                        });
            }
        });
    }
}
