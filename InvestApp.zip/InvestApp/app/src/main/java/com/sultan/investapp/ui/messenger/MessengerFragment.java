package com.sultan.investapp.ui.messenger;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sultan.investapp.R;
import com.sultan.investapp.model.UserModel;
import com.sultan.investapp.ui.activity.MainActivity;
import com.sultan.investapp.ui.adapter.UsersAdapter;
import com.sultan.investapp.utils.Constants;
import com.sultan.investapp.utils.ItemClickSupport;
import com.sultan.investapp.utils.SessionManager;
import com.sultan.investapp.viewmodel.MessengerViewModel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MessengerFragment extends Fragment implements ItemClickSupport.OnItemClickListener {

    private MessengerViewModel messengerViewModel;
    RecyclerView recyclerViewUserList;
    UsersAdapter usersAdapter;
    SessionManager sm;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_messenger, container, false);

        sm = new SessionManager(requireContext());
        usersAdapter = new UsersAdapter();
        recyclerViewUserList = v.findViewById(R.id.recyclerview_users);
        recyclerViewUserList.setLayoutManager(new LinearLayoutManager(requireContext()));
        ItemClickSupport.addTo(recyclerViewUserList)
                .setOnItemClickListener(this);
        recyclerViewUserList.setAdapter(usersAdapter);

        messengerViewModel = new ViewModelProvider(this).get(MessengerViewModel.class);
        messengerViewModel.getUsers();

        messengerViewModel.getUserList().observe(getViewLifecycleOwner(), list -> {
            usersAdapter.setUsers(list);
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        MainActivity.updateNavigationBarState(R.id.messenger_nav);
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, int position, View v) {
        String chatRef = "";
        if (sm.getUserEmail().compareTo(usersAdapter.getUser(position).getEmail()) > 0)
            chatRef = cleanEmailAddress(sm.getUserEmail()) + "_" + cleanEmailAddress(usersAdapter.getUser(position).getEmail());
        else
            chatRef = cleanEmailAddress(cleanEmailAddress(usersAdapter.getUser(position).getEmail() + "_" + sm.getUserEmail()));

        Intent chatIntent = new Intent(requireActivity(), ChatActivity.class);
        chatIntent.putExtra(Constants.EXTRA_CURRENT_USER_ID, sm.getUserUid());
        chatIntent.putExtra(Constants.EXTRA_RECIPIENT_ID, usersAdapter.getUser(position).getUid());
        chatIntent.putExtra(Constants.EXTRA_CHAT_REF, chatRef);

        requireActivity().startActivity(chatIntent);
    }

    private String cleanEmailAddress(String email) {
        return email.replace(".", "-");
    }

}
