package com.sultan.investapp.model;

import android.os.Build;

import androidx.annotation.NonNull;

public class AuthParams {
    private final String email;
    private final String password;
    public AuthParams(final String email, final String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    @NonNull
    @Override
    public String toString() {
        return "AuthParams{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' + '}';
    }

    private static final String TAG = AuthParams.class.toString();
}
