package com.sultan.investapp.ui.registration;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sultan.investapp.R;
import com.sultan.investapp.model.UserModel;
import com.sultan.investapp.utils.SessionManager;

public class RegistrationFragment extends Fragment {

    EditText fullname, email, password, retypePassword;
    Button registration;
    FirebaseAuth mAuth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_registration, container, false);

        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        fullname = v.findViewById(R.id.edittext_fullname);
        email = v.findViewById(R.id.edittext_email);
        password = v.findViewById(R.id.edittext_password);
        retypePassword = v.findViewById(R.id.edittext_retype_password);
        registration = v.findViewById(R.id.sign_up);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        registration.setOnClickListener(v -> {
            registration.startAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.bubble));

            String userFullname = fullname.getText().toString().trim();
            String userEmail = email.getText().toString().trim();
            String userPassword = password.getText().toString().trim();
            String userRetypePassword = retypePassword.getText().toString().trim();

            if (userFullname.isEmpty() || userFullname.length() < 1) {
                fullname.setError("Input your full name");
            }
            else if (userEmail.isEmpty() || userEmail.length() < 1) {
                email.setError("Input correct E-Mail");
            } else if (userPassword.isEmpty() || userPassword.length() < 1) {
                password.setError("Input your password");
            }
            else if (!userPassword.equals(userRetypePassword)) {
                retypePassword.setError("Password mismatch");
            } else {
                mAuth.createUserWithEmailAndPassword(userEmail, userPassword)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                firebaseDatabase = FirebaseDatabase.getInstance("https://investapp-a067a-default-rtdb.europe-west1.firebasedatabase.app");
                                databaseReference = firebaseDatabase
                                        .getReference()
                                        .child("users");

                                SessionManager sm = new SessionManager(requireContext());
                                sm.saveUserKey(databaseReference.push().getKey());
                                databaseReference.push().setValue(new UserModel(userFullname, userEmail, task.getResult().getUser().getUid()));

                                Snackbar.make(v, "Successfully signed up", Snackbar.LENGTH_SHORT).show();
                                NavHostFragment.findNavController(RegistrationFragment.this)
                                        .navigate(RegistrationFragmentDirections.actionRegistrationFragmentToLoginFragment());
                            }
                        });
            }
        });
    }
}
